#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// Tipo dos elementos no conjunto.
typedef char* SType;

// Define como os elementos do conjunto serão organizados na memória.
typedef struct node{
  SType key;
  int tam;
  struct node* prev;
  struct node* next;
} Node;

// Define um tipo de dado set (Conjunto).
typedef struct {
  Node* end;  // Ponteiro para o sentinela.
  int size;  // Número de elementos no conjunto.
} set;

typedef Node* iterator;

void make_set(set* s);

int empty(set* s);

int size(set* s);

iterator begin(set* s);

iterator end(set* s);

iterator next(iterator x);

iterator prev(iterator x);

SType key(iterator x);

iterator find(SType k, set* s);

void insert(SType k, set* s);

void erase(SType k, set* s);

void clear(set* s);

void free_set(set* s);
