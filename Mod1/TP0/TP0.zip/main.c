#include "lista.h"

int cmp(const void* a, const void* b){
	return *(char*)a - *(char*)b;
}

int main(int argc, char const *argv[]){
	int* grupos;

	set palavras;
	make_set(&palavras);

	int n; 
	scanf("%d", &n);

	char minhaPalavra[51];
	char separador;
	while(n--){
		do{
			scanf("%s%c", minhaPalavra, &separador);
			qsort(minhaPalavra, strlen(minhaPalavra), sizeof(char), cmp);
			insert(minhaPalavra, &palavras);
		}while(separador == ' ');

		grupos = (int*)calloc(size(&palavras), sizeof(int));

		iterator i;
		int j = 0;
		for (i = begin(&palavras); i != end(&palavras); i = next(i)) {
			grupos[j] = i->tam;
			j++;
		}

		qsort(grupos, size(&palavras), sizeof(int), cmp);

		for (j = size(&palavras)-1; j >= 0 ; j--){
			printf("%d ", grupos[j]);
		}printf("\n");

		free(grupos);
		clear(&palavras);
	}

	return 0;
}