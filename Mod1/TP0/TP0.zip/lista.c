#include "lista.h"

void make_set(set* s) {
  s->size = 0;
  s->end = malloc(sizeof(Node));
  s->end->next = s->end;
  s->end->prev = s->end;
}

int empty(set* s) {
  return s->size == 0;
}

int size(set* s){
  return s->size;
}

iterator begin(set* s) {
  return s->end->next;
}

iterator end(set* s) {
  return s->end;
}

iterator next(iterator x) {
  return x->next;
}

iterator prev(iterator x) {
  return x->prev;
}

SType key(iterator x) {
  return x->key;
}

iterator find(SType k, set* s) {
  iterator i;
  for (i = begin(s); i != end(s); i = next(i)) {
    if (strcmp(key(i), k) == 0){
      return i;
    } else if (strcmp(key(i), k) > 0) {
      return end(s);
    }
  }
  return end(s);
}

void insert(SType k, set* s) {
  Node* x = begin(s);
  while (x != end(s) && strcmp(key(x), k) < 0) {
    x = next(x);
  }
  if(x != end(s) && strcmp(x->key, k) == 0){
    x->tam++;
  }
  if (x == end(s) || strcmp(key(x), k) != 0){
    Node* node = malloc(sizeof(Node));
    node->tam = 1;
    node->key = (char*)malloc(strlen(k)+1 * sizeof(char));
    strcpy(node->key, k);
    node->prev = prev(x);
    node->next = x;
    x->prev->next = node;
    x->prev = node;
    s->size++;
  }
}

void erase(SType k, set* s) {
  Node* x = find(k, s);
  if (x != end(s)) {
    x->prev->next = x->next;
    x->next->prev = x->prev;
    free(x);
    s->size--;
  }
}

void clear(set* s) {
  while (!empty(s)) {
    erase(key(begin(s)), s);
  }
}

void free_set(set* s) {
  clear(s);
  free(s->end);
}
